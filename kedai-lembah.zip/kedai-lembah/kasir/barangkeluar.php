<?php
include '../modules/header.php';
include '../config/is_kasir.php';
?>

<title>Barang Keluar</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'barangkeluar/tampil.php';
    break;
  case 'tambah':
    include 'barangkeluar/tambah.php';
    break;
  case 'export':
    include 'barangkeluar/export.php';
    break;
  case 'exportdetail':
    include 'barangkeluar/exportdetail.php';
    break;
  case 'exportbulan':
    include 'barangkeluar/exportbulan.php';
    break;
  case 'edit':
    include 'barangkeluar/edit.php';
    break;
  case 'detail':
    include 'barangkeluar/detail.php';
    break;
  case 'proses':
    include 'barangkeluar/proses.php';
    break;
  case 'hapus':
    include 'barangkeluar/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>