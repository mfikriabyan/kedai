 <?php
  ini_set('date.timezone', 'Asia/Makassar');
  ?>
 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Transaksi</h1>

   <div class="card card-body">
     <div class="row">
       <div class="col-12">
         <?php
          if (isset($_SESSION['result'])) {
            if ($_SESSION['result'] == 'success') {
          ?>
             <!-- Success -->
             <div class="alert alert-success alert-dismissible fade show" role="alert">
               <strong><?= $_SESSION['message'] ?></strong>
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <!-- Success -->
           <?php
            } else {
            ?>
             <!-- danger -->
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
               <strong><?= $_SESSION['message'] ?></strong>
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <!-- danger -->
         <?php
            }
            unset($_SESSION['result']);
            unset($_SESSION['message']);
          }
          ?>

       </div>
       <div class="col-12">
         <form action="transaksi.php?page=proses" method="post">
           <div class="row">
             <div class="col-9">
               <div class="form-group">
                 <label>Pilih Pelanggan</label>
                 <select class="form-control" name="pelanggan_id">
                   <option value="">Pilih</option>
                   <?php
                    include_once '../config/koneksi.php';
                    $querypelanggan = "SELECT * FROM pelanggan ORDER BY id_pelanggan DESC";
                    $resultpelanggan = mysqli_query($koneksi, $querypelanggan);
                    while ($pelanggan = mysqli_fetch_assoc($resultpelanggan)) {
                    ?>
                     <option value="<?= $pelanggan['id_pelanggan']; ?>"><?= $pelanggan['nama']; ?></option>
                   <?php } ?>
                 </select>
               </div>
             </div>
             <div class="col-3">
               <div class="form-group">
                 <label>Jam Transaksi</label>
                 <input type="datetime" name="jam_transaksi" class="form-control " id="jam_transaksi" placeholder="Jam Transaksi ..." value="<?= date('Y-m-d\ H:i:s'); ?>">
               </div>
             </div>

             <div class="col-3">
               <div class="form-group">
                 <label>Pilih Karyawan</label>
                 <select class="form-control" name="karyawan_id">
                   <option value="">Pilih</option>
                   <?php
                    include_once '../config/koneksi.php';
                    $querykaryawan = "SELECT * FROM karyawan ORDER BY id_karyawan DESC";
                    $resultkaryawan = mysqli_query($koneksi, $querykaryawan);
                    while ($karyawan = mysqli_fetch_assoc($resultkaryawan)) {
                    ?>
                     <option value="<?= $karyawan['id_karyawan']; ?>"><?= $karyawan['namak']; ?></option>
                   <?php } ?>
                 </select>
               </div>
             </div>
             <div class="col-4">
               <div class="form-group">
                 <label>Pilih Metode Pembayaran</label>
                 <select class="form-control" name="metode_pembayaran">
                   <option value="Tunai">Tunai</option>
                   <option value="Transfer">Transfer</option>
                 </select>
               </div>
             </div>
           </div>



           <h4>Detail Pesanan</h4>
           <hr>

           <div class="box" id="wrapper-detail">

             <div class="row" style="width: 100%">
               <div class="col-4">
                 <div class="form-group">
                   <label>Pilih Menu</label>
                   <select class="form-control selectMenu" name="menu_id[]" id="selectMenu">
                     <option value="">Pilih</option>
                     <?php
                      include_once '../config/koneksi.php';
                      $querymenu = "SELECT * FROM menu ORDER BY id_menu DESC";
                      $resultmenu = mysqli_query($koneksi, $querymenu);
                      while ($menu = mysqli_fetch_assoc($resultmenu)) {
                      ?>
                       <option value="<?= $menu['id_menu']; ?>"><?= $menu['nama_menu']; ?></option>
                     <?php } ?>
                   </select>
                 </div>
               </div>
               <div class="col-2">
                 <div class="form-group">
                   <label>Jumlah</label>
                   <input type="number" name="jumlah_pesanan[]" class="form-control " id="jumlah_pesanan" placeholder="Banyaknya ...">
                 </div>
               </div>
               <div class="col-3">
                 <div class="form-group">
                   <label>Harga Satuan</label>

                   <input type="number" min=0 name="harga_satuan[]" class="form-control " id="harga" id="harga_satuan" placeholder="Harga Satuan ...">
                 </div>
               </div>
               <div class="col-1 d-flex align-items-center pt-2">
                 <a href="#" class="btn btn-success" id="btnTambah">Tambah</a>
               </div>
             </div>

           </div>

           <button name="tambah" value="tambah" class="btn btn-primary">Simpan</button>
         </form>
       </div>
     </div>
   </div>

 </div>

 <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
 <script>
   $(document).ready(function() {
     var max_fields = 10;
     var wrapper = $("#wrapper-detail");
     var add_button = $("#btnTambah");

     var x = 1; //initlal text box count
     $(add_button).click(function(e) { //on add input button click
       e.preventDefault();
       if (x < max_fields) { //max input box allowed
         x++; //text box increment
         $(wrapper).append(`
         <div class="row" style="width: 100%">
               <div class="col-4">
                 <div class="form-group">
                   <label>Pilih Menu</label>
                   <select class="form-control selectMenu" name="menu_id[]" id="selectMenu">
                   <option value="">Pilih</option>
                     <?php
                      include_once '../config/koneksi.php';
                      $querymenu = "SELECT * FROM menu ORDER BY id_menu DESC";
                      $resultmenu = mysqli_query($koneksi, $querymenu);
                      while ($menu = mysqli_fetch_assoc($resultmenu)) {
                      ?>
                       <option value="<?= $menu['id_menu']; ?>"><?= $menu['nama_menu']; ?></option>
                     <?php } ?>
                   </select>
                 </div>
               </div>
               <div class="col-2">
                 <div class="form-group">
                   <label>Jumlah</label>
                   <input type="number" name="jumlah_pesanan[]" class="form-control " id="jumlah_pesanan" placeholder="Banyaknya ...">
                 </div>
               </div>
               <div class="col-3">
                 <div class="form-group">
                   <label>Harga Satuan</label>

                   <input type="number" min=0 name="harga_satuan[]" class="form-control " id="harga" id="harga_satuan" placeholder="Harga Satuan ...">
                 </div>
               </div>
               <div class="col-1 d-flex align-items-center pt-2">
                 <a href="#" class="btn btn-danger remove_field" >Hapus</a>
               </div>
             </div>
            `); //add input box
       }
     });

     $(wrapper).on("click", ".remove_field", function(e) { //user click on remove text
       e.preventDefault();
       $(this).closest('.row').remove();
       x--;
     })
     $(add_button).click(function(e) {
       auto();
     });

     function auto() {
       $('.selectMenu').each(function() {
         var ini = $(this);
         ini.change(function() {
           var id = $(this).val();
           var harga = ini.closest('.row').find('#harga');
           $.ajax({
             url: 'transaksi/get-menu.php',
             method: "POST",
             data: {
               id: id
             },
             success: function(res) {
               if (res) {
                 harga.val(res);
               } else {
                 harga.val(null);
               }
             }
           });
         });
       });
     }

     auto();

   });
 </script>
 <!-- /.container-fluid -->