<?php
include '../modules/header.php';
include '../config/is_kasir.php';
?>

<title>Dashboard</title>

<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">INI KASIR</h1>

</div>
<!-- /.container-fluid -->

<?php
include '../modules/footer.php';
?>