<?php
include '../config/koneksi.php';


$nama_menu = $_POST['nama_menu'];
$harga = $_POST['harga'];
$kategori_id = $_POST['kategori_id'];

if (isset($_POST['tambah'])) {
  $query = "INSERT INTO menu (nama_menu,kategori_id,harga) VALUES ('$nama_menu','$kategori_id','$harga')";
  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan';

    header("Location: menu.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = mysqli_error($koneksi);
    //refresh page
    header("Location: menu.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_menu = $_POST['id_menu'];

  $query = "UPDATE menu SET nama_menu = '$nama_menu', harga = '$harga', kategori_id = '$kategori_id' WHERE id_menu = '$id_menu'";

  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location: menu.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = mysqli_error($koneksi);
    //refresh page
    header("Location: menu.php?page=edit");
  }
}
