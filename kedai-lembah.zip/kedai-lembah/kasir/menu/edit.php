 <title>Kategori</title>

 <?php
  include '../config/koneksi.php';
  // get id from url
  if (!isset($_GET['id_menu'])) {
    header("Location: menu.php");
  } else {
    $id_menu = $_GET['id_menu'];
    // get data from database
    $query = "SELECT * FROM menu WHERE id_menu = '$id_menu'";
    $result = mysqli_query($koneksi, $query);
    $row = mysqli_fetch_assoc($result);
  }

  ?>

 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Menu</h1>

   <div class="col-12">
     <form action="menu.php?page=proses" method="post">
       <input type="hidden" name="id_menu" value="<?= $id_menu ?>">

       <div class="form-group">
         <label for="nama_menu">Nama Menu</label>
         <input type="text" class="form-control" id="nama_menu" name="nama_menu" value="<?= $row['nama_menu'] ?>">
       </div>
       <div class="form-group">
         <label>Pilih Kategori</label>
         <select class="form-control" name="kategori_id">
           <?php
            include_once '../config/koneksi.php';
            $querykategori = "SELECT * FROM kategori ORDER BY id_kategori DESC";
            $resultkategori = mysqli_query($koneksi, $querykategori);
            while ($kategori = mysqli_fetch_assoc($resultkategori)) {
            ?>
             <option value="<?= $kategori['id_kategori']; ?>" <?= $row['kategori_id'] == $kategori['id_kategori'] ? 'selected' : '' ?>>
               <?= $kategori['nama_kategori']; ?></option>
           <?php } ?>
         </select>
       </div>
       <div class="form-group">
         <label for="harga">Harga</label>
         <input type="text" class="form-control" id="harga" name="harga" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" value="<?= $row['harga'] ?>">
       </div>

       <button name="update" value="update" class="btn btn-primary">Simpan</button>
     </form>
   </div>
 </div>
 </div>

 </div>
 <!-- /.container-fluid -->