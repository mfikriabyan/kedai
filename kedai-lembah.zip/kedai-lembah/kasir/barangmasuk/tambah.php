 <title>Barang</title>

 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Barang Masuk</h1>

   <div class="card card-body">
     <div class="row">
       <div class="col-12">
         <?php
          if (isset($_SESSION['result'])) {
            if ($_SESSION['result'] == 'success') {
          ?>
             <!-- Success -->
             <div class="alert alert-success alert-dismissible fade show" role="alert">
               <strong><?= $_SESSION['message'] ?></strong>
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <!-- Success -->
           <?php
            } else {
            ?>
             <!-- danger -->
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
               <strong><?= $_SESSION['message'] ?></strong>
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <!-- danger -->
         <?php
            }
            unset($_SESSION['result']);
            unset($_SESSION['message']);
          }
          ?>

       </div>
       <div class="col-9">
         <form action="barangmasuk.php?page=proses" method="post">
           <div class="form-group">
             <label>Pilih Suplier</label>
             <select class="form-control" name="suplier_id">
               <?php
                include_once '../config/koneksi.php';
                $querysuplier = "SELECT * FROM suplier ORDER BY id_suplier DESC";
                $resultsuplier = mysqli_query($koneksi, $querysuplier);
                while ($suplier = mysqli_fetch_assoc($resultsuplier)) {
                ?>
                 <option value="<?= $suplier['id_suplier']; ?>"><?= $suplier['nama_suplier']; ?></option>
               <?php } ?>
             </select>
           </div>
           <div class="col-3">
             <div class="form-group">
               <label>Tanggal Masuk</label>
               <input type="date" name="tgl_masuk" class="form-control " id="tgl_masuk" placeholder="Harga Satuan ...">
             </div>
           </div>

           <h4>Detail Barang Masuk</h4>
           <hr>

           <div class="box" id="wrapper-detail">

             <div class="row" style="width: 100%">
               <div class="col-4">
                 <div class="form-group">
                   <label>Pilih Barang</label>
                   <select class="form-control" name="barang_id[]">
                     <?php
                      include_once '../config/koneksi.php';
                      $querybarang = "SELECT * FROM tb_barang ORDER BY id_barang DESC";
                      $resultbarang = mysqli_query($koneksi, $querybarang);
                      while ($barang = mysqli_fetch_assoc($resultbarang)) {
                      ?>
                       <option value="<?= $barang['id_barang']; ?>"><?= $barang['nama_barang']; ?></option>
                     <?php } ?>
                   </select>
                 </div>
               </div>
               <div class="col-2">
                 <div class="form-group">
                   <label>Banyaknya</label>
                   <input type="number" name="jumlah_masuk[]" class="form-control " id="jumlah_masuk" placeholder="Banyaknya ...">
                 </div>
               </div>
               <div class="col-3">
                 <div class="form-group">
                   <label>Harga Satuan</label>

                   <input type="number" min=0 name="harga_satuan[]" class="form-control " id="harga_satuan" placeholder="Harga Satuan ...">
                 </div>
               </div>
               <div class="col-1 d-flex align-items-center pt-2">
                 <a href="#" class="btn btn-success" id="btnTambah">Tambah</a>
               </div>
             </div>

           </div>

           <button name="tambah" value="tambah" class="btn btn-primary">Simpan</button>
         </form>
       </div>
     </div>
   </div>

 </div>

 <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
 <script>
   $(document).ready(function() {
     var max_fields = 10;
     var wrapper = $("#wrapper-detail");
     var add_button = $("#btnTambah");

     var x = 1; //initlal text box count
     $(add_button).click(function(e) { //on add input button click
       e.preventDefault();
       if (x < max_fields) { //max input box allowed
         x++; //text box increment
         $(wrapper).append(`
          <div class="row" style="width: 100%">
               <div class="col-4">
                 <div class="form-group">
                   <label>Pilih Barang</label>
                   <select class="form-control" name="barang_id[]">
                     <?php
                      include_once '../config/koneksi.php';
                      $querybarang = "SELECT * FROM tb_barang ORDER BY id_barang DESC";
                      $resultbarang = mysqli_query($koneksi, $querybarang);
                      while ($barang = mysqli_fetch_assoc($resultbarang)) {
                      ?>
                       <option value="<?= $barang['id_barang']; ?>"><?= $barang['nama_barang']; ?></option>
                     <?php } ?>
                   </select>
                 </div>
               </div>
               <div class="col-2">
                 <div class="form-group">
                   <label>Banyaknya</label>
                   <input type="number" name="jumlah_masuk[]" class="form-control " id="jumlah_masuk" placeholder="Banyaknya ...">
                 </div>
               </div>
               <div class="col-3">
                 <div class="form-group">
                   <label>Harga Satuan</label>
                   <input type="number" name="harga_satuan[]" class="form-control " id="harga_satuan" placeholder="Harga Satuan ...">
                 </div>
               </div>
               <div class="col-1 d-flex align-items-center pt-2">
                 <a href="#" class="btn btn-danger remove_field" >Tambah</a>
               </div>
             </div>
            `); //add input box
       }
     });

     $(wrapper).on("click", ".remove_field", function(e) { //user click on remove text
       e.preventDefault();
       $(this).closest('.row').remove();
       x--;
     })
   });
 </script>
 <!-- /.container-fluid -->