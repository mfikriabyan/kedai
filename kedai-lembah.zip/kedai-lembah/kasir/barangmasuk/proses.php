<?php
include '../config/koneksi.php';

$suplier_id = $_POST['suplier_id'];
$barang_id = $_POST['barang_id'];
$jumlah_masuk = $_POST['jumlah_masuk'];
$harga_satuan = $_POST['harga_satuan'];
$tgl_masuk = $_POST['tgl_masuk'];
$tgl_terakhir_masuk = date('Y-m-d');

if (isset($_POST['tambah'])) {
  $queryBarangMasuk = "INSERT INTO barang_masuk (suplier_id, total_harga, tgl_masuk) VALUES ('$suplier_id', '0', '$tgl_masuk')";

  $resultBarangMasuk = mysqli_query($koneksi, $queryBarangMasuk);



  if ($resultBarangMasuk) {

    $last_id = mysqli_insert_id($koneksi);

    $updateSuplier = "UPDATE suplier SET tgl_terakhir_masuk = '$tgl_terakhir_masuk' WHERE id_suplier = $suplier_id ";

    $resultUpdateSuplier = mysqli_query($koneksi, $updateSuplier);

    if (!$resultUpdateSuplier) {
      // make a success message with session
      $_SESSION['result'] = 'error';
      $_SESSION['message'] = mysqli_error($koneksi);
      //refresh page
      header("Location: barangmasuk.php?page=tambah");
    }

    $count = count((array) $_POST['barang_id']);

    $total_harga = 0;
    for ($i = 0; $i < $count; $i++) {
      $queryDetail = "INSERT INTO detail_barang_masuk (barang_masuk_id, barang_id, jumlah_masuk, harga_satuan) VALUES ('$last_id', '{$_POST['barang_id'][$i]}', '{$_POST['jumlah_masuk'][$i]}', '{$_POST['harga_satuan'][$i]}' ) ";

      $updateBarang = "UPDATE tb_barang SET tgl_terakhir_masuk = '$tgl_terakhir_masuk' WHERE id_barang = {$_POST['barang_id'][$i]} ";

      $resultUpdateBarang = mysqli_query($koneksi, $updateBarang);

      if (!$resultUpdateBarang) {
        // make a success message with session
        $_SESSION['result'] = 'error';
        $_SESSION['message'] = mysqli_error($koneksi);
        //refresh page
        header("Location: barangmasuk.php?page=tambah");
      }

      $total_harga += $_POST['jumlah_masuk'][$i] * $_POST['harga_satuan'][$i];

      $resultDetailBm = mysqli_query($koneksi, $queryDetail);

      if (!$resultDetailBm) {
        // make a success message with session
        $_SESSION['result'] = 'error';
        $_SESSION['message'] = mysqli_error($koneksi);
        //refresh page
        header("Location: barangmasuk.php?page=tambah");
      }
    }

    $updateBm = "UPDATE barang_masuk SET total_harga = '$total_harga' WHERE id_barang_masuk = $last_id ";

    $resultUpdateBm = mysqli_query($koneksi, $updateBm);

    if (!$resultUpdateBm) {
      // make a success message with session
      $_SESSION['result'] = 'error';
      $_SESSION['message'] = mysqli_error($koneksi);
      //refresh page
      header("Location: barangmasuk.php?page=tambah");
    }

    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan';

    header("Location: barangmasuk.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = mysqli_error($koneksi);
    //refresh page
    header("Location: barangmasuk.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_barang_masuk = $_POST['id_barang_masuk'];

  $queryUpdateBmFirst = "UPDATE barang_masuk SET suplier_id = '$suplier_id' WHERE id_barang_masuk = '$id_barang_masuk'";

  $resultUpdateBmFirst = mysqli_query($koneksi, $queryUpdateBmFirst);

  if ($resultUpdateBmFirst) {

    $updateSuplier = "UPDATE suplier SET tgl_terakhir_masuk = '$tgl_terakhir_masuk' WHERE id_suplier = $suplier_id ";

    $resultUpdateSuplier = mysqli_query($koneksi, $updateSuplier);

    if (!$resultUpdateSuplier) {
      // make a success message with session
      $_SESSION['result'] = 'error';
      $_SESSION['message'] = mysqli_error($koneksi);
      //refresh page
      header("Location: barangmasuk.php?page=tambah");
    }

    $deleteDetailBm = "DELETE FROM detail_barang_masuk WHERE barang_masuk_id = $id_barang_masuk";

    $resultDeleteDetailBm = mysqli_query($koneksi, $deleteDetailBm);

    if (!$resultDeleteDetailBm) {
      // make a success message with session
      $_SESSION['result'] = 'error';
      $_SESSION['message'] = mysqli_error($koneksi);
      //refresh page
      header("Location: barangmasuk.php?page=tambah");
    }

    $count = count((array) $_POST['barang_id']);

    $total_harga = 0;
    for ($i = 0; $i < $count; $i++) {
      $queryDetail = "INSERT INTO detail_barang_masuk (barang_masuk_id, barang_id, jumlah_masuk, harga_satuan) VALUES ('$id_barang_masuk', '{$_POST['barang_id'][$i]}', '{$_POST['jumlah_masuk'][$i]}', '{$_POST['harga_satuan'][$i]}' ) ";

      $updateBarang = "UPDATE tb_barang SET tgl_terakhir_masuk = '$tgl_terakhir_masuk' WHERE id_barang = {$_POST['barang_id'][$i]} ";

      $resultUpdateBarang = mysqli_query($koneksi, $updateBarang);

      if (!$resultUpdateBarang) {
        // make a success message with session
        $_SESSION['result'] = 'error';
        $_SESSION['message'] = mysqli_error($koneksi);
        //refresh page
        header("Location: barangmasuk.php?page=tambah");
      }

      $total_harga += $_POST['jumlah_masuk'][$i] * $_POST['harga_satuan'][$i];

      $resultDetailBm = mysqli_query($koneksi, $queryDetail);

      if (!$resultDetailBm) {
        // make a success message with session
        $_SESSION['result'] = 'error';
        $_SESSION['message'] = mysqli_error($koneksi);
        //refresh page
        header("Location: barangmasuk.php?page=tambah");
      }
    }

    $updateBm = "UPDATE barang_masuk SET total_harga = '$total_harga' WHERE id_barang_masuk = $id_barang_masuk ";

    $resultUpdateBm = mysqli_query($koneksi, $updateBm);

    if (!$resultUpdateBm) {
      // make a success message with session
      $_SESSION['result'] = 'error';
      $_SESSION['message'] = mysqli_error($koneksi);
      //refresh page
      header("Location: barangmasuk.php?page=tambah");
    }

    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location: barangmasuk.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal diperbarui';
    //refresh page
    header("Location: barangmasuk.php?page=tambah");
  }
}
