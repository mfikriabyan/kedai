<?php
if ($_SESSION['role'] != 'Kasir') {
  header("Location: ../login.php");
  exit();
}
