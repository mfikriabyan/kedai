<?php
session_start();
if ($_SESSION['login']) {

  // header("Location: ../admin/dashboard.php");
  if ($_SESSION['role'] == 'admin') {

    header("Location: ../admin/transaksi.php");
    exit();
  } elseif ($_SESSION['role'] == 'Kasir') {

    header("Location: ../kasir/transaksi.php");
    exit();
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Username / Password tidak cocok!';
    //refresh page
    header("Location: ../login.php");
  }
} else {
  header("Location: ../login.php");
  exit();
}
