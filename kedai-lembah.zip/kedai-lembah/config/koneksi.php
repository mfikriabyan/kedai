<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "db_skripsi";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
  echo "Koneksi Gagal";
}
