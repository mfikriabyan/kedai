<?php
// check login status
if (isset($_SESSION['login'])) {
  echo 'sudah login';
} else {
  echo 'belum login';
  // redirect to login page
  header('Location: login.php');
}
