<?php
include '../config/koneksi.php';

$nama = $_POST['nama'];
$email = $_POST['email'];
$nohp = $_POST['nohp'];

if (isset($_POST['tambah'])) {
  $query = "INSERT INTO pelanggan (nama, nohp, email) VALUES ('$nama','$nohp','$email')";

  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan';

    header("Location: pelanggan.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = mysqli_error($koneksi);
    //refresh page
    header("Location: pelanggan.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_pelanggan = $_POST['id_pelanggan'];
  $query = "UPDATE pelanggan SET  nama = '$nama', nohp = '$nohp',  email = '$email' WHERE id_pelanggan = '$id_pelanggan'";


  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location: pelanggan.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal diperbarui';
    //refresh page
    header("Location: pelanggan.php?page=tambah");
  }
}
