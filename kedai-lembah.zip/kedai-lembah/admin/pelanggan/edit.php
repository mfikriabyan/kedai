 <title>Pelanggan</title>

 <?php
  include '../config/koneksi.php';
  // get id from url
  if (!isset($_GET['id_pelanggan'])) {
    header("Location: pelanggan.php");
  } else {
    $id_pelanggan = $_GET['id_pelanggan'];
    // get data from database
    $query = "SELECT * FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'";
    $result = mysqli_query($koneksi, $query);
    $row = mysqli_fetch_assoc($result);
  }

  ?>

 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Suplier </h1>

   <div class="card card-body">
     <div class="row">
       <div class="col-12">
         <form action="pelanggan.php?page=proses" method="post" enctype="multipart/form-data">
           <input type="hidden" name="id_pelanggan" value="<?= $id_pelanggan ?>">
           <div class="col-6">
             <div class="form-group">
               <label for="nama_suplier">Nama Pelanggan</label>
               <input type="text" class="form-control" id="nama_suplier" name="nama" value="<?= $row['nama'] ?>">
             </div>
           </div>

           <div class="col-6">
             <div class="form-group">
               <label for="note">Nomor Handphone</label>
               <input type="text" class="form-control" id="note" name="nohp" value="<?= $row['nohp'] ?>">
             </div>
           </div>


           <button name="update" value="update" class="btn btn-primary">Simpan</button>
         </form>
       </div>
     </div>
   </div>

 </div>
 <!-- /.container-fluid -->