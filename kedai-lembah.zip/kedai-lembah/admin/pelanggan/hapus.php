<?php
include '../config/koneksi.php';
$id_pelanggan = $_GET['id_pelanggan'];
// make deleete query

$query = "DELETE FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'";

$result = mysqli_query($koneksi, $query);
if ($result) {
  // make a success message with session
  $_SESSION['result'] = 'success';
  $_SESSION['message'] = 'Data berhasil dihapus';

  header("Location: pelanggan.php");
} else {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = 'Data gagal dihapus';
  //refresh page
  header("Location: pelanggan.php?page=tambah");
}
