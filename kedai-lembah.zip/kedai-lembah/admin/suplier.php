<?php
include '../modules/header.php';
include '../config/is_admin.php';
?>

<title>Suplier</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'suplier/tampil.php';
    break;
  case 'tambah':
    include 'suplier/tambah.php';
    break;
  case 'export':
    include 'suplier/export.php';
    break;
  case 'edit':
    include 'suplier/edit.php';
    break;
  case 'proses':
    include 'suplier/proses.php';
    break;
  case 'hapus':
    include 'suplier/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>