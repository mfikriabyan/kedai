<?php
include '../modules/header.php';
include '../config/is_admin.php';
?>

<title>Dashboard</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'barang/tampil.php';
    break;
  case 'tambah':
    include 'barang/tambah.php';
    break;
  case 'export':
    include 'barang/export.php';
    break;
  case 'edit':
    include 'barang/edit.php';
    break;
  case 'proses':
    include 'barang/proses.php';
    break;
  case 'hapus':
    include 'barang/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>