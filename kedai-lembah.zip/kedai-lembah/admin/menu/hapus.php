<?php
include '../config/koneksi.php';
$id_menu = $_GET['id_menu'];
// make deleete query
$query = "DELETE FROM menu WHERE id_menu = '$id_menu'";

$result = mysqli_query($koneksi, $query);
if ($result) {
  // make a success message with session
  $_SESSION['result'] = 'success';
  $_SESSION['message'] = 'Data berhasil dihapus';

  header("Location: menu.php");
} else {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = 'Data gagal dihapus';
  //refresh page
  header("Location: menu.php");
}
