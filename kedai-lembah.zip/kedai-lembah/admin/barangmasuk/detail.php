 <?php
  ini_set('date.timezone', 'Asia/Makassar');

  include '../config/koneksi.php';
  // get id from url
  if (!isset($_GET['id_barang_masuk'])) {
    header("Location: barangmasuk.php");
  } else {
    $id_barang_masuk = $_GET['id_barang_masuk'];
    // get data from database
    $query = "SELECT * FROM barang_masuk 
    JOIN suplier ON suplier.id_suplier = barang_masuk.suplier_id
    WHERE id_barang_masuk = '$id_barang_masuk'";
    $result = mysqli_query($koneksi, $query);
    $row = mysqli_fetch_assoc($result);
  }

  ?>

 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Barang Masuk </h1>

   <div class="card card-body">
     <div class="row">
       <div class="col-12">
         <table class="table table-bordered">
           <tr>
             <th width="200px">Nama Suplier</th>
             <td><?= $row['nama_suplier'] ?></td>
           </tr>
           <tr>
             <th>Tanggal Masuk</th>
             <td><?= $row['tgl_masuk'] ?></td>
           </tr>

           <tr>
             <th>Detail Belanja</th>
             <td>
               <table class="table table-bordered">
                 <tr>
                   <th>Nama Barang</th>
                   <th>Jumlah Masuk</th>
                   <th>Harga</th>
                   <th>Sub Total</th>
                 </tr>
                 <?php
                  include_once '../config/koneksi.php';
                  $no = 1;
                  $queryDetail = "SELECT * FROM detail_barang_masuk 
                  JOIN tb_barang ON tb_barang.id_barang = detail_barang_masuk.barang_id
                  WHERE barang_masuk_id = '$id_barang_masuk'";
                  $resultDetail = mysqli_query($koneksi, $queryDetail);
                  while ($detail = mysqli_fetch_assoc($resultDetail)) {
                  ?>

                   <tr>
                     <td><?= $detail['nama_barang'] ?></td>
                     <td><?= $detail['jumlah_masuk'] ?></td>
                     <td><?= number_format($detail['harga_satuan'], 0, ',', '.') ?></td>
                     <td><?= number_format($detail['harga_satuan'] * $detail['jumlah_masuk'], 0, ',', '.') ?></td>
                   </tr>
                 <?php
                  } ?>
                 <tr>
                   <td colspan="3" class="font-weight-bold text-center">Total</td>
                   <td>Rp . <?= number_format($row['total_harga']) ?> </td>
                 </tr>
               </table>
               <a href="barangmasuk.php?page=exportdetail&id_barang_masuk=<?= $row['id_barang_masuk']; ?>" class="btn btn-info" target="_blank">Print Data</a>

             </td>
           </tr>
         </table>
       </div>
     </div>
   </div>

 </div>