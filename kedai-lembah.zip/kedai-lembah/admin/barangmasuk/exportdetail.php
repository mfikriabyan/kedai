<?php

/**
 * Html2Pdf Library - example
 *
 * HTML => PDF converter
 * distributed under the OSL-3.0 License
 *
 * @package   Html2pdf
 * @author    Laurent MINGUET <webmaster@html2pdf.fr>
 * @copyright 2017 Laurent MINGUET
 */
require_once  '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
use Spipu\Html2Pdf\Exception\Html2PdfException;
use Spipu\Html2Pdf\Exception\ExceptionFormatter;

try {
  ob_start();
?>

  <!DOCTYPE html>
  <html lang="eng">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
      .table {
        border-collapse: collapse;
        width: 100vw;

      }

      th,
      td {
        padding: 8px;

      }

      table.bordered th,
      table.bordered td {
        border: 1px solid black;
      }

      table.bordered th {
        text-align: center;
      }
    </style>

  </head>

  <body>
    <!-- kop surat -->
    <table class="table">
      <colgroup>
        <col style="width: 10%" class="angka">
        <col style="width: 75%" class="angka">
        <col style="width: 10%" class="angka">
      </colgroup>
      <tr>
        <td>
          <img src="../assets/img/logo.png" height="90" alt="" class="gambar">
        </td>
        <td style="text-align: center; padding: 16px 48px;">


          <span style="font-size: 20px;font-weight: bold;text-align: center;">Kedai Lembah Martapura</span>
          <br>
          <span style="font-size: 12px;font-weight: lighter;text-align: center;">Jl. A.Yani KM 35,5 Martpura, <br> Kabupaten Banjar, Kalimantan Selatan</span>
        </td>
        <td>

        </td>
      </tr>
    </table>
    <!-- kop surat -->


    <hr>
    <?php
    ini_set('date.timezone', 'Asia/Makassar');

    include '../config/koneksi.php';
    // get id from url
    if (!isset($_GET['id_barang_masuk'])) {
      header("Location: barangmasuk.php");
    } else {
      $id_barang_masuk = $_GET['id_barang_masuk'];
      // get data from database
      $query = "SELECT * FROM barang_masuk 
      JOIN suplier ON suplier.id_suplier = barang_masuk.suplier_id
      WHERE id_barang_masuk = '$id_barang_masuk'";
      $result = mysqli_query($koneksi, $query);
      $row = mysqli_fetch_assoc($result);
    }

    ?>

    <br>
    <h2 style="text-align: center;">Data Detail Barang Masuk </h2>
    <br>

    <table>
      <tr>
        <th width="200px">Nama Suplier : </th>
        <td><?= $row['nama_suplier'] ?></td>
      </tr>
      <tr>
        <th>Tanggal Masuk :</th>
        <td><?= $row['tgl_masuk'] ?></td>
      </tr>
    </table>

    <table class="table bordered">
      <colgroup>
        <col style="width: 10%" class="angka">
        <col style="width: 30%" class="angka">
        <col style="width: 20%" class="angka">
        <col style="width: 20%" class="angka">
        <col style="width: 20%" class="angka">

      </colgroup>
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Barang</th>
          <th>Jumlah Masuk</th>
          <th>Harga</th>
          <th>Sub Total</th>
        </tr>
      </thead>
      <tbody>
        <?php
        include_once '../config/koneksi.php';
        $no = 1;
        $queryDetail = "SELECT * FROM detail_barang_masuk 
        JOIN tb_barang ON tb_barang.id_barang = detail_barang_masuk.barang_id
        WHERE barang_masuk_id = '$id_barang_masuk'";
        $resultDetail = mysqli_query($koneksi, $queryDetail);
        while ($detail = mysqli_fetch_assoc($resultDetail)) {
        ?>
          <tr>
            <td><?= $no++; ?></td>
            <td><?= $detail['nama_barang']; ?></td>
            <td><?= $detail['jumlah_masuk']; ?></td>
            <td><?= number_format($detail['harga_satuan'], 0, ',', '.'); ?></td>
            <td><?= number_format($detail['harga_satuan'] * $detail['jumlah_masuk'], 0, ',', '.'); ?></td>
          </tr>
        <?php } ?>
        <tr>
          <td colspan="4" class="font-weight-bold text-center">Total</td>
          <td>Rp . <?= number_format($row['total_harga']) ?> </td>
        </tr>
      </tbody>
    </table>

    <br>
    <br>
    <br>

    <table class="table ">
      <colgroup>
        <col style="width: 60%" class="angka">
        <col style="width: 40%" class="angka">
      </colgroup>

      <?php
      switch (date('m')) {
        case '01':
          $bln = 'Januari';
          break;
        case '02':
          $bln = 'Februari';
          break;
        case '03':
          $bln = 'Maret';
          break;
        case '04':
          $bln = 'April';
          break;
        case '05':
          $bln = 'Mei';
          break;
        case '06':
          $bln = 'Juni';
          break;
        case '07':
          $bln = 'Juli';
          break;
        case '08':
          $bln = 'Agustus';
          break;
        case '09':
          $bln = 'September';
          break;
        case '10':
          $bln = 'Oktober';
          break;
        case '11':
          $bln = 'November';
          break;
        case '12':
          $bln = 'Desember';
          break;

        default:
          # code...
          break;
      }
      ?>

      <tr style="text-align: right;">
        <td></td>
        <td>Martapura, <?= date('d') . ' ' . $bln . ' ' . date('Y')  ?> </td>
      </tr>
      <tr style="text-align: right;">
        <td></td>
        <td>Manager</td>
      </tr>
      <tr style="text-align: right;">
        <td></td>
        <td>
          <br><br><br><br>
        </td>
      </tr>
      <tr style="text-align: right;">
        <td></td>
        <td>
          Muhammad Ilham Ramadhan
        </td>
      </tr>
    </table>

  </body>

  </html>

<?php

  $content = ob_get_clean();
  ob_clean();
  $html2pdf = new Html2Pdf('P', 'A4', 'fr');
  $html2pdf->pdf->SetDisplayMode('fullpage');
  $html2pdf->writeHTML($content);
  $html2pdf->output('example05.pdf');
} catch (Html2PdfException $e) {
  $html2pdf->clean();

  $formatter = new ExceptionFormatter($e);
  echo $formatter->getHtmlMessage();
}
?>