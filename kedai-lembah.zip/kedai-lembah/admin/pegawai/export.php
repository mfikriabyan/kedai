<?php

/**
 * Html2Pdf Library - example
 *
 * HTML => PDF converter
 * distributed under the OSL-3.0 License
 *
 * @package   Html2pdf
 * @author    Laurent MINGUET <webmaster@html2pdf.fr>
 * @copyright 2017 Laurent MINGUET
 */
require_once  '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
use Spipu\Html2Pdf\Exception\Html2PdfException;
use Spipu\Html2Pdf\Exception\ExceptionFormatter;

try {
  ob_start();
?>

  <!DOCTYPE html>
  <html lang="eng">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
      .table {
        border-collapse: collapse;
        width: 100vw;

      }

      th,
      td {
        padding: 8px;

      }

      table.bordered th,
      table.bordered td {
        border: 1px solid black;
      }

      table.bordered th {
        text-align: center;
      }
    </style>

  </head>

  <body>

    <table>
      <colgroup>
        <col style="width: 10%" class="angka">
        <col style="width: 80%" class="angka">
        <col style="width: 10%" class="angka">
      </colgroup>
      <tr>
        <td>
          <img src="../assets/img/banjar.png" height="90" alt="" class="gambar">
        </td>
        <td style="text-align: center; padding: 16px 48px;">
          <span style="font-size: 16px;font-weight: bold;">PEMERINTAH KABUPATEN BARITO UTARA</span>
          <br>
          <span style="font-size: 20px;font-weight: bold;">DINAS BADAN PENGELOLAAN <br> KEUANGAN DAN ASET DAERAH</span>
          <br>
          <span style="font-size: 12px;font-weight: lighter;">Jl. Yetro Sinseng No.31 Muara Teweh Nomor Telepon (0519) 21068 Nomor Fax (0519) 23978</span>
        </td>
        <td>
          <img src="../assets/img/banjar.png" height="90" alt="" class="gambar">

        </td>
      </tr>
    </table>

    <hr>


    <br>
    <h2 style="text-align: center;">Data Pegawai</h2>
    <br>

    <table class="table bordered">
      <colgroup>
        <col style="width: 10%" class="angka">
        <col style="width: 40%" class="angka">
        <col style="width: 20%" class="angka">
        <col style="width: 30%" class="angka">
      </colgroup>
      <thead>
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>Jenis Kelamin</th>
          <th>Jabatan</th>
        </tr>
      </thead>
      <tbody>
        <?php
        include_once '../config/koneksi.php';

        $no = 1;
        $query = "SELECT * FROM tb_pegawai ORDER BY id_pegawai DESC";
        $result = mysqli_query($koneksi, $query);
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
          <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['nama']; ?></td>
            <td><?= $row['jk']; ?></td>
            <td><?= $row['jabatan']; ?></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>

    <br>
    <br>
    <br>

    <table class="table ">
      <colgroup>
        <col style="width: 60%" class="angka">
        <col style="width: 40%" class="angka">
      </colgroup>

      <tr style="text-align: right;">
        <td></td>
        <td>Martapura, 10 Januari 2022</td>
      </tr>
      <tr style="text-align: right;">
        <td></td>
        <td>Pimpinan</td>
      </tr>
      <tr style="text-align: right;">
        <td></td>
        <td>
          <br><br><br><br>
        </td>
      </tr>
      <tr style="text-align: right;">
        <td></td>
        <td>
          Muhammad Hapiz
        </td>
      </tr>
    </table>


  </body>

  </html>

<?php

  $content = ob_get_clean();
  ob_clean();
  $html2pdf = new Html2Pdf('P', 'A4', 'fr');
  $html2pdf->pdf->SetDisplayMode('fullpage');
  $html2pdf->writeHTML($content);
  $html2pdf->output('example05.pdf');
} catch (Html2PdfException $e) {
  $html2pdf->clean();

  $formatter = new ExceptionFormatter($e);
  echo $formatter->getHtmlMessage();
}
?>