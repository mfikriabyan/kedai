 <title>Pegawai</title>

 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Pegawai </h1>

   <div class="card card-body">
     <div class="row">
       <div class="col-12">
         <?php
          if (isset($_SESSION['result'])) {
            if ($_SESSION['result'] == 'success') {
              ?>
             <!-- Success -->
             <div class="alert alert-success alert-dismissible fade show" role="alert">
               <strong><?= $_SESSION['message'] ?></strong>
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <!-- Success -->
           <?php
              } else {
                ?>
             <!-- danger -->
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
               <strong><?= $_SESSION['message'] ?></strong>
               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <!-- danger -->
         <?php
            }
            unset($_SESSION['result']);
            unset($_SESSION['message']);
          }
          ?>

       </div>
       <div class="col-12">
         <form action="pegawai.php?page=proses" method="post" enctype="multipart/form-data">
           <div class="row">
             <div class="col-6">
               <div class="form-group">
                 <label>Gambar</label>
                 <input type="file" name="gambar" class="form-control">
               </div>
             </div>
             <div class="col-6">
               <div class="form-group">
                 <label for="nama">Nama</label>
                 <input type="text" class="form-control" id="nama" name="nama" required>
               </div>
             </div>
           </div>
           <div class="form-group">
             <label for="jk">Jenis Kelamin</label>
             <select class="form-control" id="jk" name="jk">
               <option value="L">Laki-Laki</option>
               <option value="P">Perempuan</option>
             </select>
           </div>
           <div class="form-group">
             <label for="jabatan">Jabatan</label>
             <select class="form-control" id="jabatan" name="jabatan">
               <option value="Admin">Admin</option>
               <option value="Kasir">Kasir</option>
               <option value="Pelayan">Pelayan</option>
             </select>
           </div>
           <div class="form-group">
             <label for="jabatan">Barang</label>
             <select class="form-control" id="jabatan" name="barang_id">
               <?php
                include_once '../config/koneksi.php';
                $queryBarang = "SELECT * FROM tb_barang ORDER BY id_barang DESC";
                $resultBarang = mysqli_query($koneksi, $queryBarang);
                while ($barang = mysqli_fetch_assoc($resultBarang)) {
                  ?>
                 <option value="<?= $barang['id_barang']; ?>"><?= $barang['nama_barang']; ?></option>
               <?php } ?>
             </select>
           </div>
           <button name="tambah" value="tambah" class="btn btn-primary">Simpan</button>
         </form>
       </div>
     </div>
   </div>

 </div>
 <!-- /.container-fluid -->