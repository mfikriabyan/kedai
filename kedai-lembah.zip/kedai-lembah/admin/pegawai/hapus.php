<?php
include '../config/koneksi.php';
$id_pegawai = $_GET['id_pegawai'];
// make deleete query

$get_foto = "SELECT gambar FROM tb_pegawai WHERE id_pegawai='$id_pegawai'";
$data_foto = mysqli_query($koneksi, $get_foto);
// Mengubah data yang diambil menjadi Array
$foto_lama = mysqli_fetch_array($data_foto);

// Menghapus Foto lama didalam folder FOTO
unlink("../foto/" . $foto_lama['gambar']);


$query = "DELETE FROM tb_pegawai WHERE id_pegawai = '$id_pegawai'";

$result = mysqli_query($koneksi, $query);
if ($result) {
  // make a success message with session
  $_SESSION['result'] = 'success';
  $_SESSION['message'] = 'Data berhasil dihapus';

  header("Location: pegawai.php");
} else {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = 'Data gagal dihapus';
  //refresh page
  header("Location: pegawai.php?page=tambah");
}
