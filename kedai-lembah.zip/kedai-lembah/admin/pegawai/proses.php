<?php
include '../config/koneksi.php';

$nama = $_POST['nama'];
$jk = $_POST['jk'];
$jabatan = $_POST['jabatan'];
$barang_id = $_POST['barang_id'];
$nama_gambar = $_FILES['gambar']['name'];
$size_gambar = $_FILES['gambar']['size'];

if (isset($_POST['tambah'])) {

  if (!file_exists($_FILES['gambar']['tmp_name']) || !is_uploaded_file($_FILES['gambar']['tmp_name'])) {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Harap Pilih Foto !';
    //refresh page
    header("Location: pegawai.php?page=tambah");
    die;
  }
  if ($size_gambar > 2097152) {
    // Jika File lebih dari 2 MB maka akan gagal mengupload File
    header("Location: pegawai.php");
  } else {
    // Ekstensi yang diperbolehkan untuk diupload boleh diubah sesuai keinginan
    $ekstensi_izin = array('png', 'jpg', 'jepg');
    // Memisahkan nama file dengan Ekstensinya
    $pisahkan_ekstensi = explode('.', $nama_gambar);
    $ekstensi = strtolower(end($pisahkan_ekstensi));
    // Nama file yang berada di dalam direktori temporer server
    $file_tmp = $_FILES['gambar']['tmp_name'];
    // Membuat angka/huruf acak berdasarkan waktu diupload
    // Menyatukan angka/huruf acak dengan nama file aslinya
    $nama_gambar_new = $nama_gambar;

    if (in_array($ekstensi, $ekstensi_izin) === true) {
      // Memindahkan File kedalam Folder "FOTO"
      move_uploaded_file($file_tmp, '../foto/' . $nama_gambar_new);
    }
  }

  $query = "INSERT INTO tb_pegawai (gambar, nama, jk, jabatan, barang_id) VALUES ('$nama_gambar_new','$nama', '$jk', '$jabatan','$barang_id')";

  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan';

    header("Location: pegawai.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal ditambahkan';
    //refresh page
    header("Location: pegawai.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_pegawai = $_POST['id_pegawai'];

  if (!file_exists($_FILES['gambar']['tmp_name']) || !is_uploaded_file($_FILES['gambar']['tmp_name'])) {
    // TIDAK ADA GAMBAR YG DIUPLOAD
    $query = "UPDATE tb_pegawai SET  nama = '$nama', jk = '$jk', jabatan = '$jabatan', barang_id = '$barang_id' WHERE id_pegawai = '$id_pegawai'";
  } else {
    // ADA GAMBAR YG DIUPLOAD
    if ($size_gambar > 2097152) {
      // Jika File lebih dari 2 MB maka akan gagal mengupload File
      header("Location: pegawai.php");
    } else {
      // Ekstensi yang diperbolehkan untuk diupload boleh diubah sesuai keinginan
      $ekstensi_izin = array('png', 'jpg', 'jepg');
      // Memisahkan nama file dengan Ekstensinya
      $pisahkan_ekstensi = explode('.', $nama_gambar);
      $ekstensi = strtolower(end($pisahkan_ekstensi));
      // Nama file yang berada di dalam direktori temporer server
      $file_tmp = $_FILES['gambar']['tmp_name'];
      // Membuat angka/huruf acak berdasarkan waktu diupload
      // Menyatukan angka/huruf acak dengan nama file aslinya
      $nama_gambar_new = $nama_gambar;

      if (in_array($ekstensi, $ekstensi_izin) === true) {
        // Memindahkan File kedalam Folder "FOTO"
        move_uploaded_file($file_tmp, '../foto/' . $nama_gambar_new);
      }
    }
    $query = "UPDATE tb_pegawai SET gambar = '$nama_gambar_new', nama = '$nama', jk = '$jk', jabatan = '$jabatan', barang_id = '$barang_id' WHERE id_pegawai = '$id_pegawai'";
  }

  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location: pegawai.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal diperbarui';
    //refresh page
    header("Location: pegawai.php?page=tambah");
  }
}
