<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Transaksi </h1>

  <div class="card card-body">
    <div class="row">
      <div class="col-12 d-flex justify-content-between">
        <a href="transaksi.php?page=tambah" class="btn btn-primary">Tambah Data</a>
        <div>
          <a href="transaksi.php?page=export" class="btn btn-info" target="_blank">Print Data</a>
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exportBulanModal">
            Print Perbulan
          </button>
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exportpelangganModal">
            Print Per Pelanggan
          </button>
        </div>
      </div>
    </div>
  </div>

  <div class="card card-body mt-2">
    <div class="row">
      <div class="col-12">
        <?php
        if (isset($_SESSION['result'])) {
          if ($_SESSION['result'] == 'success') {
        ?>
            <!-- Success -->
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong><?= $_SESSION['message'] ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <!-- Success -->
          <?php
          } else {
          ?>
            <!-- danger -->
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong><?= $_SESSION['message'] ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <!-- danger -->
        <?php
          }
          unset($_SESSION['result']);
          unset($_SESSION['message']);
        }
        ?>

      </div>
      <div class="col-12">
        <table class="table table-bordered" id="mytable" style="width: 100%;">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Pelanggan</th>
              <th>Jam Transaksi</th>
              <th>Metode Pembayaran</th>
              <th>Total Transaksi</th>
              <th style="width: 150px;" class="not-export-col">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            include_once '../config/koneksi.php';
            $no = 1;
            $query = "SELECT * FROM transaksi 
            JOIN pelanggan ON pelanggan.id_pelanggan = transaksi.pelanggan_id
            JOIN karyawan ON karyawan.id_karyawan = transaksi.karyawan_id
            ORDER BY id_transaksi DESC";
            $result = mysqli_query($koneksi, $query);
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['nama']; ?></td>
                <td><?= $row['jam_transaksi']; ?></td>
                <td><?= $row['metode_pembayaran']; ?></td>
                <td><?= 'Rp ' . number_format($row['total_belanja'], 0, ',', '.'); ?></td>
                <td class="not-export-col">
                  <a href="transaksi.php?page=detail&id_transaksi=<?= $row['id_transaksi']; ?>" class="btn btn-info">Detail</a>
                  <a href="transaksi.php?page=hapus&id_transaksi=<?= $row['id_transaksi']; ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin ingin menghapus data')">Hapus</a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<div class="modal fade" id="exportBulanModal" tabindex="-1" aria-labelledby="exportBulanModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exportBulanModalLabel">Pilih Bulan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="transaksi.php" method="get" id="print" target="_blank">
          <input type="hidden" name="page" value="exportbulan">
          <div class="form-group">
            <label for="Pilih Bulan">Bulan</label>
            <select class="custom-select" name="bulan">
              <option selected>Pilih</option>
              <option value="1">Januari</option>
              <option value="2">Februari</option>
              <option value="3">Maret</option>
              <option value="4">April</option>
              <option value="5">Mei</option>
              <option value="6">Juni</option>
              <option value="7">Juli</option>
              <option value="8">Agustus</option>
              <option value="9">September</option>
              <option value="10">Oktober</option>
              <option value="11">November</option>
              <option value="12">Desember</option>
            </select>
          </div>

          <div class="form-group">
            <label>Tahun</label>
            <input type="text" class="form-control" name="tahun" value="<?= date('Y') ?>">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" form="print">Print</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exportpelangganModal" tabindex="-1" aria-labelledby="exportpelangganModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exportpelangganModalLabel">Pilih Pelanggan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="transaksi.php" method="get" id="printPelanggan" target="_blank">
          <input type="hidden" name="page" value="exportperpelanggan">
          <div class="form-group">
            <label for="Pilih Bulan">Bulan</label>
            <select class="form-control" name="pelanggan_id">
              <option value="">Pilih</option>
              <?php
              include_once '../config/koneksi.php';
              $querypelanggan = "SELECT * FROM pelanggan ORDER BY id_pelanggan DESC";
              $resultpelanggan = mysqli_query($koneksi, $querypelanggan);
              while ($pelanggan = mysqli_fetch_assoc($resultpelanggan)) {
              ?>
                <option value="<?= $pelanggan['id_pelanggan']; ?>"><?= $pelanggan['nama']; ?></option>
              <?php } ?>
            </select>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" form="printPelanggan">Print</button>
      </div>
    </div>
  </div>
</div>