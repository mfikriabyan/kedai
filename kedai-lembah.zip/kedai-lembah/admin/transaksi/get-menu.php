<?php
include_once '../../config/koneksi.php';
$id = $_POST['id'];
$query = "SELECT harga FROM menu WHERE id_menu = '$id'";
$result = mysqli_query($koneksi, $query);
$row = mysqli_fetch_assoc($result);
echo $row['harga'];
