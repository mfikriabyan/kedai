 <?php
  ini_set('date.timezone', 'Asia/Makassar');

  include '../config/koneksi.php';
  // get id from url
  if (!isset($_GET['id_transaksi'])) {
    header("Location: transaksi.php");
  } else {
    $id_transaksi = $_GET['id_transaksi'];
    // get data from database
    $query = "SELECT *, pelanggan.nama AS nama_pelanggan, karyawan.namak AS nama_karyawan FROM transaksi 
    JOIN pelanggan ON transaksi.pelanggan_id = pelanggan.id_pelanggan
    JOIN karyawan ON transaksi.karyawan_id = karyawan.id_karyawan
    WHERE id_transaksi = '$id_transaksi'";
    $result = mysqli_query($koneksi, $query);
    $row = mysqli_fetch_assoc($result);
  }

  ?>

 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Transaksi </h1>

   <div class="card card-body">
     <div class="row">
       <div class="col-12">
         <table class="table table-bordered">
           <tr>
             <th width="200px">Nama Pelanggan</th>
             <td><?= $row['nama_pelanggan'] ?></td>
           </tr>
           <tr>
             <th>Jam Transaksi</th>
             <td><?= $row['jam_transaksi'] ?></td>
           </tr>
           <tr>
             <th>Metode Pembayaran</th>
             <td><?= $row['metode_pembayaran'] ?></td>
           </tr>
           <tr>
             <th>Karyawan</th>
             <td><?= $row['nama_karyawan'] ?></td>
           </tr>
           <tr>
             <th>Detail Belanja</th>
             <td>
               <table class="table table-bordered">
                 <tr>
                   <th>Nama Menu</th>
                   <th>Jumlah Pesanan</th>
                   <th>Harga</th>
                   <th>Sub Total</th>
                 </tr>
                 <?php
                  include_once '../config/koneksi.php';
                  $no = 1;
                  $queryDetail = "SELECT * FROM detail_transaksi 
                  JOIN menu ON menu.id_menu = detail_transaksi.menu_id
                  WHERE transaksi_id = '$id_transaksi'";
                  $resultDetail = mysqli_query($koneksi, $queryDetail);
                  while ($detail = mysqli_fetch_assoc($resultDetail)) {
                  ?>
                   <tr>
                     <td><?= $detail['nama_menu'] ?></td>
                     <td><?= $detail['jumlah_pesanan'] ?></td>
                     <td><?= number_format($detail['harga_menu'], 0, ',', '.') ?></td>
                     <td><?= number_format($detail['harga_menu'] * $detail['jumlah_pesanan'], 0, ',', '.') ?></td>
                   </tr>
                 <?php
                  } ?>
                 <tr>
                   <td colspan="3" class="font-weight-bold text-center">Total</td>
                   <td>Rp . <?= number_format($row['total_belanja']) ?> </td>
                 </tr>

               </table>
               <a href="transaksi.php?page=exportdetail&id_transaksi=<?= $row['id_transaksi']; ?>" class="btn btn-info" target="_blank">Print Data</a>

             </td>
           </tr>
         </table>
       </div>
     </div>
   </div>

 </div>