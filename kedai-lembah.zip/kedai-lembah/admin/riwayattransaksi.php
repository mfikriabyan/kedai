<?php
include '../modules/header.php';
include '../config/is_admin.php';
?>

<title>Transaksi</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'riwayattransaksi/tampil.php';
    break;
  case 'tambah':
    include 'riwayattransaksi/tambah.php';
    break;
  case 'export':
    include 'riwayattransaksi/export.php';
    break;
  case 'exportdetail':
    include 'riwayattransaksi/exportdetail.php';
    break;
  case 'exportbulan':
    include 'riwayattransaksi/exportbulan.php';
    break;
  case 'exportperpelanggan':
    include 'riwayattransaksi/exportperpelanggan.php';
    break;
  case 'detail':
    include 'riwayattransaksi/detail.php';
    break;
  case 'proses':
    include 'riwayattransaksi/proses.php';
    break;
  case 'hapus':
    include 'riwayattransaksi/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>