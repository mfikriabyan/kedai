<?php
include '../config/koneksi.php';
$id_barang_masuk = $_GET['id_barang_masuk'];

$deleteDetailBm = "DELETE FROM detail_barang_masuk WHERE barang_masuk_id = $id_barang_masuk";

$resultDeleteDetailBm = mysqli_query($koneksi, $deleteDetailBm);

if (!$resultDeleteDetailBm) {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = mysqli_error($koneksi);
  //refresh page
  header("Location: barangmasuk.php?page=tambah");
}

// make deleete query
$query = "DELETE FROM barang_masuk WHERE id_barang_masuk = '$id_barang_masuk'";

$result = mysqli_query($koneksi, $query);
if ($result) {
  // make a success message with session
  $_SESSION['result'] = 'success';
  $_SESSION['message'] = 'Data berhasil dihapus';

  header("Location: barangmasuk.php");
} else {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = 'Data gagal dihapus';
  //refresh page
  header("Location: barangmasuk.php");
}
