 <?php
  ini_set('date.timezone', 'Asia/Makassar');

  include '../config/koneksi.php';
  // get id from url
  if (!isset($_GET['id_barang_keluar'])) {
    header("Location: barangkeluar.php");
  } else {
    $id_barang_keluar = $_GET['id_barang_keluar'];
    // get data from database
    $query = "SELECT * FROM barang_keluar 
    WHERE id_barang_keluar = '$id_barang_keluar'";
    $result = mysqli_query($koneksi, $query);
    $row = mysqli_fetch_assoc($result);
  }

  ?>

 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Barang Keluar</h1>

   <div class="card card-body">
     <div class="row">
       <div class="col-12">
         <table class="table table-bordered">

           <tr>
             <th>Tanggal Keluar</th>
             <td><?= $row['tgl_keluar'] ?></td>
           </tr>

           <tr>
             <th>Detail Barang Terpakai</th>
             <td>
               <table class="table table-bordered">
                 <tr>
                   <th>Nama Barang</th>
                   <th>Jumlah Keluar</th>
                 </tr>
                 <?php
                  include_once '../config/koneksi.php';
                  $no = 1;
                  $queryDetail = "SELECT * FROM detail_barang_keluar 
                  JOIN tb_barang ON tb_barang.id_barang = detail_barang_keluar.barang_id
                  WHERE barang_keluar_id = '$id_barang_keluar'";
                  $resultDetail = mysqli_query($koneksi, $queryDetail);
                  while ($detail = mysqli_fetch_assoc($resultDetail)) {
                  ?>

                   <tr>
                     <td><?= $detail['nama_barang'] ?></td>
                     <td><?= $detail['jumlah_keluar'] ?></td>

                   </tr>
                 <?php
                  } ?>

               </table>

             </td>
           </tr>
         </table>
         <a href="barangkeluar.php?page=exportdetail&id_barang_keluar=<?= $row['id_barang_keluar']; ?>" class="btn btn-info" target="_blank">Print Data</a>

       </div>
     </div>
   </div>

 </div>