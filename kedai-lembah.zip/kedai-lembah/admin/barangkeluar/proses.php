<?php
include '../config/koneksi.php';

$barang_id = $_POST['barang_id'];

$tgl_keluar = $_POST['tgl_keluar'];


if (isset($_POST['tambah'])) {
  $queryBarangKeluar = "INSERT INTO barang_keluar (`id_barang_keluar`, `tgl_keluar`) VALUES (NULL, '$tgl_keluar')";

  $resultBarangKeluar = mysqli_query($koneksi, $queryBarangKeluar);

  if ($resultBarangKeluar) {

    $last_id = mysqli_insert_id($koneksi);


    $count = count((array) $_POST['barang_id']);

    $total_harga = 0;
    for ($i = 0; $i < $count; $i++) {
      $queryDetailbarangkeluar = "INSERT INTO detail_barang_keluar (barang_keluar_id, barang_id, jumlah_keluar) VALUES ('$last_id', '{$_POST['barang_id'][$i]}', '{$_POST['jumlah_keluar'][$i]}' ) ";

      $query = "SELECT * FROM barang WHERE id_barang = '{$_POST['barang_id'][$i]}'";
      $result = mysqli_query($koneksi, $query);
      $barangx = mysqli_fetch_assoc($result);
      $slsh = $barangx['jumlah_tersedia'] - $_POST['jumlah_keluar'][$i];

      if ($slsh < 0) {

        $_SESSION['result'] = 'error';
        $_SESSION['message'] = 'Stok Tidak Mencukupi!';
        //refresh page
        header("Location: barangkeluar.php?page=tambah");
        die;
      }

      $updateBarangkeluar = "UPDATE tb_barang SET jumlah_tersedia = jumlah_tersedia - {$_POST['jumlah_keluar'][$i]} WHERE id_barang = {$_POST['barang_id'][$i]} ";

      $resultUpdateBarang = mysqli_query($koneksi, $updateBarangkeluar);

      if (!$resultUpdateBarang) {
        // make a success message with session
        $_SESSION['result'] = 'error';
        $_SESSION['message'] = mysqli_error($koneksi);
        //refresh page
        header("Location: barangkeluar.php?page=tambah");
      }


      $resultDetailbarangkeluar = mysqli_query($koneksi, $queryDetailbarangkeluar);

      if (!$resultDetailbarangkeluar) {
        // make a success message with session
        $_SESSION['result'] = 'error';
        $_SESSION['message'] = mysqli_error($koneksi);
        //refresh page
        header("Location: barangkeluar.php?page=tambahi");
      }
    }


    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan nah';

    header("Location: barangkeluar.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = mysqli_error($koneksi);
    //refresh page
    header("Location: barangkeluar.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_barang_masuk = $_POST['id_barang_masuk'];

  $queryUpdateBmFirst = "UPDATE barang_masuk SET suplier_id = '$suplier_id' WHERE id_barang_masuk = '$id_barang_masuk'";

  $resultUpdateBmFirst = mysqli_query($koneksi, $queryUpdateBmFirst);

  if ($resultUpdateBmFirst) {

    $updateSuplier = "UPDATE suplier SET tgl_terakhir_masuk = '$tgl_terakhir_masuk' WHERE id_suplier = $suplier_id ";

    $resultUpdateSuplier = mysqli_query($koneksi, $updateSuplier);

    if (!$resultUpdateSuplier) {
      // make a success message with session
      $_SESSION['result'] = 'error';
      $_SESSION['message'] = mysqli_error($koneksi);
      //refresh page
      header("Location: barangmasuk.php?page=tambah");
    }

    $deleteDetailBm = "DELETE FROM detail_barang_masuk WHERE barang_masuk_id = $id_barang_masuk";

    $resultDeleteDetailBm = mysqli_query($koneksi, $deleteDetailBm);

    if (!$resultDeleteDetailBm) {
      // make a success message with session
      $_SESSION['result'] = 'error';
      $_SESSION['message'] = mysqli_error($koneksi);
      //refresh page
      header("Location: barangmasuk.php?page=tambah");
    }

    $count = count((array) $_POST['barang_id']);

    $total_harga = 0;
    for ($i = 0; $i < $count; $i++) {
      $queryDetail = "INSERT INTO detail_barang_masuk (barang_masuk_id, barang_id, jumlah_masuk, harga_satuan) VALUES ('$id_barang_masuk', '{$_POST['barang_id'][$i]}', '{$_POST['jumlah_masuk'][$i]}', '{$_POST['harga_satuan'][$i]}' ) ";

      $updateBarang = "UPDATE tb_barang SET tgl_terakhir_masuk = '$tgl_terakhir_masuk' WHERE id_barang = {$_POST['barang_id'][$i]} ";

      $resultUpdateBarang = mysqli_query($koneksi, $updateBarang);

      if (!$resultUpdateBarang) {
        // make a success message with session
        $_SESSION['result'] = 'error';
        $_SESSION['message'] = mysqli_error($koneksi);
        //refresh page
        header("Location: barangmasuk.php?page=tambah");
      }

      $total_harga += $_POST['jumlah_masuk'][$i] * $_POST['harga_satuan'][$i];

      $resultDetailBm = mysqli_query($koneksi, $queryDetail);

      if (!$resultDetailBm) {
        // make a success message with session
        $_SESSION['result'] = 'error';
        $_SESSION['message'] = mysqli_error($koneksi);
        //refresh page
        header("Location: barangmasuk.php?page=tambah");
      }
    }

    $updateBm = "UPDATE barang_masuk SET total_harga = '$total_harga' WHERE id_barang_masuk = $id_barang_masuk ";

    $resultUpdateBm = mysqli_query($koneksi, $updateBm);

    if (!$resultUpdateBm) {
      // make a success message with session
      $_SESSION['result'] = 'error';
      $_SESSION['message'] = mysqli_error($koneksi);
      //refresh page
      header("Location: barangmasuk.php?page=tambah");
    }

    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location: barangmasuk.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal diperbarui';
    //refresh page
    header("Location: barangmasuk.php?page=tambah");
  }
}
