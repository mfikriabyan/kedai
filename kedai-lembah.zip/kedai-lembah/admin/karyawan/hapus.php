<?php
include '../config/koneksi.php';
$id_karyawan = $_GET['id_karyawan'];
// make deleete query



$query = "DELETE FROM karyawan WHERE id_karyawan = '$id_karyawan'";

$result = mysqli_query($koneksi, $query);
if ($result) {
  // make a success message with session
  $_SESSION['result'] = 'success';
  $_SESSION['message'] = 'Data berhasil dihapus';

  header("Location: karyawan.php");
} else {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = 'Data gagal dihapus';
  //refresh page
  header("Location: karyawan.php?page=tampil");
}
