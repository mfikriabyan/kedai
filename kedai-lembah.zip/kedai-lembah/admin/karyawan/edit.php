<?php
include '../config/koneksi.php';
// get id from url
if (!isset($_GET['id_karyawan'])) {
  header("Location: karyawan.php");
} else {
  $id_karyawan = $_GET['id_karyawan'];
  // get data from database
  $query = "SELECT * FROM karyawan 
  JOIN tb_user ON karyawan.user_id = tb_user.id_user 
  WHERE id_karyawan = '$id_karyawan'";
  $result = mysqli_query($koneksi, $query);
  $row = mysqli_fetch_assoc($result);
}

?>

<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Karyawan </h1>

  <div class="card card-body">
    <div class="row">
      <div class="col-12">
        <form action="karyawan.php?page=proses" method="post" enctype="multipart/form-data">
          <input type="hidden" name="id_karyawan" value="<?= $id_karyawan ?>">
          <div class="row">
            <div class="col-6">
              <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" id="namak" name="namak" value="<?= $row['namak'] ?>">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="jk">Jenis Kelamin</label>
            <select class="form-control" id="jk" name="jk">
              <option value="L" <?= $row['jk'] == 'L' ? 'selected' : '' ?>>Laki-Laki</option>
              <option value="P" <?= $row['jk'] == 'P' ? 'selected' : '' ?>>Perempuan</option>
            </select>
          </div>
          <div class="form-group">
            <label for="jabatan">Jabatan</label>
            <select class="form-control" id="jabatan" name="jabatan">
              <option value="Admin" <?= $row['jabatan'] == 'Admin' ? 'selected' : '' ?>>Admin</option>
              <option value="Kasir" <?= $row['jabatan'] == 'Kasir' ? 'selected' : '' ?>>Kasir</option>
              <option value="Pelayan" <?= $row['Pelayan'] == 'Pelayan' ? 'selected' : '' ?>>Pelayan</option>
            </select>
          </div>
          <div class="form-group">
            <label for="nohp">Nomor HP</label>
            <input type="text" class="form-control" id="nohp" name="nohp" value="<?= $row['nohp'] ?>">
          </div>
          <div class="form-group">
            <label for="tgl_lahir">Tanggal Lahir</label>
            <input type="date" class="form-control" id="tgl_lahir" name="tgl_lahir" value="<?= $row['tgl_lahir'] ?>">
          </div>
          <div class="form-group">
            <label for="tahun_masuk">Tahun Masuk</label>
            <input type="text" class="form-control" id="tahun_masuk" name="tahun_masuk" value="<?= $row['tahun_masuk'] ?>">
          </div>
          <input type="hidden" name="user_id" value="<?= $row['user_id'] ?>">

          <div class="form-group">
            <label for="tahun_masuk">Username</label>
            <input type="text" class="form-control" id="tahun_masuk" name="username" value="<?= $row['username'] ?>">
          </div>
          <div class="form-group">
            <label for="tahun_masuk">Password</label>
            <input type="password" class="form-control" id="tahun_masuk" name="password">
          </div>
          <button name="update" value="update" class="btn btn-primary">Simpan</button>
        </form>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->