<?php
include '../config/koneksi.php';

$namak = $_POST['namak'];
$jk = $_POST['jk'];
$jabatan = $_POST['jabatan'];
$tgl_lahir = $_POST['tgl_lahir'];
$tahun_masuk = $_POST['tahun_masuk'];
$nohp = $_POST['nohp'];
$username = $_POST['username'];
$password = md5($_POST['password']);


if (isset($_POST['tambah'])) {

  $queryUser = "INSERT INTO tb_user (username, password, role) VALUES ('$username', '$password', '$jabatan')";

  $resultUser = mysqli_query($koneksi, $queryUser);

  $last_id = mysqli_insert_id($koneksi);

  $query = "INSERT INTO karyawan (namak, jk, jabatan, tgl_lahir, tahun_masuk, nohp, user_id) VALUES ('$namak', '$jk', '$jabatan','$tgl_lahir', '$tahun_masuk', '$nohp', '$last_id')";

  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan';

    header("Location: karyawan.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = mysqli_error($koneksi);
    //refresh page
    header("Location: karyawan.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_karyawan = $_POST['id_karyawan'];
  $user_id = $_POST['user_id'];

  if ($password) {

    $queryupdateuser = "UPDATE tb_user SET username ='$username', password='$password' WHERE id_user = '$user_id'";
  } else {
    $queryupdateuser = "UPDATE tb_user SET username ='$username' WHERE id_user = '$user_id'";
  }
  $resultupdateuser = mysqli_query($koneksi, $queryupdateuser);

  $query = "UPDATE karyawan SET  namak = '$namak', jk = '$jk', jabatan = '$jabatan', tgl_lahir = '$tgl_lahir', tahun_masuk = '$tahun_masuk', nohp = '$nohp' WHERE id_karyawan = '$id_karyawan'";


  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location:karyawan.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal diperbarui';
    //refresh page
    header("Location:karyawan.php?page=edit&id_karyawan=<?= $id_karyawan;");
  }
}
