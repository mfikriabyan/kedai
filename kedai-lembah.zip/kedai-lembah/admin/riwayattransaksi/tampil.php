<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Laporan Penjualan </h1>

  <div class="card card-body">
    <div class="row">
      <div class="col-12 d-flex justify-content-between">
        <div>
          <a href="riwayattransaksi.php?page=export" class="btn btn-info" target="_blank">Print Data</a>
        </div>
      </div>
    </div>
  </div>

  <div class="card card-body mt-2">
    <div class="row">
      <div class="col-12">
        <?php
        if (isset($_SESSION['result'])) {
          if ($_SESSION['result'] == 'success') {
        ?>
            <!-- Success -->
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong><?= $_SESSION['message'] ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <!-- Success -->
          <?php
          } else {
          ?>
            <!-- danger -->
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong><?= $_SESSION['message'] ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <!-- danger -->
        <?php
          }
          unset($_SESSION['result']);
          unset($_SESSION['message']);
        }
        ?>

      </div>
      <div class="col-12">
        <table class="table table-bordered" id="mytable" style="width: 100%;">
          <thead>
            <tr>
              <th>No</th>
              <th>Tahun</th>
              <th>Bulan</th>
              <th>Total Transaksi</th>
              <th>Total Modal</th>
              <th>Penghasilan Bersih</th>
            </tr>
          </thead>
          <tbody>
            <?php
            include_once '../config/koneksi.php';
            $no = 1;
            $query = "SELECT id_transaksi, year(jam_transaksi) as tahun, month(jam_transaksi) as bulan, sum(total_belanja) as total_belanja
            FROM transaksi GROUP BY id_transaksi, tahun, bulan";
            $result = mysqli_query($koneksi, $query);
            $data = array();
            while ($row = mysqli_fetch_assoc($result)) {

              $idTransaksi = $row['id_transaksi'];
              $queryDetail = "SELECT * FROM detail_transaksi WHERE transaksi_id = '$idTransaksi'";
              $resultDetail = mysqli_query($koneksi, $queryDetail);
              $totalModal = 0;
              while ($rowDetail = mysqli_fetch_assoc($resultDetail)) {
                $queryMenu = "SELECT * FROM menu WHERE id_menu = '{$rowDetail['menu_id']}'";
                $resultMenu = mysqli_query($koneksi, $queryMenu);
                $rowMenu = mysqli_fetch_assoc($resultMenu);
                $totalModal += $rowMenu['harga_modal'] * $rowDetail['jumlah_pesanan'];
              }

              $penghasilanBersih = $row['total_belanja'] - $totalModal;

              switch ($row['bulan']) {
                case '01':
                  $bln = 'Januari';
                  break;
                case '02':
                  $bln = 'Februari';
                  break;
                case '03':
                  $bln = 'Maret';
                  break;
                case '04':
                  $bln = 'April';
                  break;
                case '05':
                  $bln = 'Mei';
                  break;
                case '06':
                  $bln = 'Juni';
                  break;
                case '07':
                  $bln = 'Juli';
                  break;
                case '08':
                  $bln = 'Agustus';
                  break;
                case '09':
                  $bln = 'September';
                  break;
                case '10':
                  $bln = 'Oktober';
                  break;
                case '11':
                  $bln = 'November';
                  break;
                case '12':
                  $bln = 'Desember';
                  break;

                default:
                  # code...
                  break;
              }
              if ($row['tahun'] == '2023') {
                $data[$row['tahun']][$row['bulan']] = ['total' => $row['total_belanja']];
              }
            ?>
              <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['tahun']; ?></td>
                <td><?= $bln; ?></td>
                <td><?= 'Rp ' . number_format($row['total_belanja'], 0, ',', '.'); ?></td>
                <td><?= 'Rp ' . number_format($totalModal, 0, ',', '.'); ?></td>
                <td><?= 'Rp ' . number_format($penghasilanBersih, 0, ',', '.'); ?></td>

              </tr>
            <?php } ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->