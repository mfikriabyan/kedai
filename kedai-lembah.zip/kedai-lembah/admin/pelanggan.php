<?php
include '../modules/header.php';
include '../config/is_admin.php';
?>

<title>Data Pelanggan</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'pelanggan/tampil.php';
    break;
  case 'tambah':
    include 'pelanggan/tambah.php';
    break;
  case 'export':
    include 'pelanggan/export.php';
    break;
  case 'exportperpelanggan':
    include 'pelanggan/exportperpelanggan.php';
    break;
  case 'edit':
    include 'pelanggan/edit.php';
    break;
  case 'proses':
    include 'pelanggan/proses.php';
    break;
  case 'hapus':
    include 'pelanggan/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>