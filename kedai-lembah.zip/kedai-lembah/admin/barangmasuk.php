<?php
include '../modules/header.php';
include '../config/is_admin.php';
?>

<title>Barang Masuk</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'barangmasuk/tampil.php';
    break;
  case 'tambah':
    include 'barangmasuk/tambah.php';
    break;
  case 'export':
    include 'barangmasuk/export.php';
    break;
  case 'exportdetail':
    include 'barangmasuk/exportdetail.php';
    break;
  case 'exportbulan':
    include 'barangmasuk/exportbulan.php';
    break;
  case 'edit':
    include 'barangmasuk/edit.php';
    break;
  case 'detail':
    include 'barangmasuk/detail.php';
    break;
  case 'proses':
    include 'barangmasuk/proses.php';
    break;
  case 'hapus':
    include 'barangmasuk/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>