<?php
include '../modules/header.php';
include '../config/is_admin.php';
?>

<title>Lapooran Laba Rugi</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'labarugi/tampil.php';
    break;
  case 'tambah':
    include 'labarugi/tambah.php';
    break;
  case 'export':
    include 'labarugi/export.php';
    break;
  case 'exportdetail':
    include 'labarugi/exportdetail.php';
    break;
  case 'exportbulan':
    include 'labarugi/exportbulan.php';
    break;
  case 'exportperpelanggan':
    include 'labarugi/exportperpelanggan.php';
    break;
  case 'detail':
    include 'labarugi/detail.php';
    break;
  case 'proses':
    include 'labarugi/proses.php';
    break;
  case 'hapus':
    include 'labarugi/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>