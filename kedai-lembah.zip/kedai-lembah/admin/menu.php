<?php
include '../modules/header.php';
include '../config/is_admin.php';
?>

<title>Menu</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'menu/tampil.php';
    break;
  case 'tambah':
    include 'menu/tambah.php';
    break;
  case 'export':
    include 'menu/export.php';
    break;
  case 'edit':
    include 'menu/edit.php';
    break;
  case 'proses':
    include 'menu/proses.php';
    break;
  case 'hapus':
    include 'menu/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>