<?php
include '../config/koneksi.php';


$nama_kategori = $_POST['nama_kategori'];
$harga = $_POST['harga'];

if (isset($_POST['tambah'])) {
  $query = "INSERT INTO kategori (nama_kategori) VALUES ('$nama_kategori')";
  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan';

    header("Location: kategori.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal ditambahkan';
    //refresh page
    header("Location: kategori.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_kategori = $_POST['id_kategori'];

  $query = "UPDATE kategori SET nama_kategori = '$nama_kategori' WHERE id_kategori = '$id_kategori'";

  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location: kategori.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal diperbarui';
    //refresh page
    header("Location: kategori.php?page=tambah");
  }
}
