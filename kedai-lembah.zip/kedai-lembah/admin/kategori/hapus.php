<?php
include '../config/koneksi.php';
$id_kategori = $_GET['id_kategori'];
// make deleete query
$query = "DELETE FROM kategori WHERE id_kategori = '$id_kategori'";

$result = mysqli_query($koneksi, $query);
if ($result) {
  // make a success message with session
  $_SESSION['result'] = 'success';
  $_SESSION['message'] = 'Data berhasil dihapus';

  header("Location: kategori.php");
} else {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = 'Data gagal dihapus';
  //refresh page
  header("Location: kategori.php");
}
