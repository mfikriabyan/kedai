<?php
include '../config/koneksi.php';
$id_barang = $_GET['id_barang'];
// make deleete query
$query = "DELETE FROM tb_barang WHERE id_barang = '$id_barang'";

$result = mysqli_query($koneksi, $query);
if ($result) {
  // make a success message with session
  $_SESSION['result'] = 'success';
  $_SESSION['message'] = 'Data berhasil dihapus';

  header("Location: barang.php");
} else {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = 'Data gagal dihapus';
  //refresh page
  header("Location: barang.php");
}
