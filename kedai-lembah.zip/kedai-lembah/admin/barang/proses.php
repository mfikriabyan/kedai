<?php
include '../config/koneksi.php';

$kode_barang = $_POST['kode_barang'];
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$merk = $_POST['merk'];
$expired = $_POST['expired'];

if (isset($_POST['tambah'])) {
  $query = "INSERT INTO tb_barang (kode_barang, nama_barang, harga, merk, expired) VALUES ('$kode_barang', '$nama_barang', '$harga', '$merk', '$expired')";
  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan';

    header("Location: barang.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal ditambahkan';
    //refresh page
    header("Location: barang.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_barang = $_POST['id_barang'];

  $query = "UPDATE tb_barang SET kode_barang = '$kode_barang', nama_barang = '$nama_barang', harga = '$harga', merk = '$merk', expired = '$expired' WHERE id_barang = '$id_barang'";

  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location: barang.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal diperbarui';
    //refresh page
    header("Location: barang.php?page=tambah");
  }
}
