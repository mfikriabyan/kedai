<?php
include '../config/koneksi.php';

$nama_suplier = $_POST['nama_suplier'];
$nohp = $_POST['nohp'];
$note = $_POST['note'];

if (isset($_POST['tambah'])) {
  $query = "INSERT INTO suplier (nama_suplier, nohp, note ) VALUES ('$nama_suplier','$nohp', '$note')";

  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil ditambahkan';

    header("Location: suplier.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = mysqli_error($koneksi);
    //refresh page
    header("Location: suplier.php?page=tambah");
  }
}

// make if block for update
if (isset($_POST['update'])) {
  $id_suplier = $_POST['id_suplier'];
  $query = "UPDATE suplier SET  nama_suplier = '$nama_suplier', nohp = '$nohp',  note = '$note' WHERE id_suplier = '$id_suplier'";


  $result = mysqli_query($koneksi, $query);

  if ($result) {
    // make a success message with session
    $_SESSION['result'] = 'success';
    $_SESSION['message'] = 'Data berhasil diperbarui';

    header("Location: suplier.php");
  } else {
    // make a success message with session
    $_SESSION['result'] = 'error';
    $_SESSION['message'] = 'Data gagal diperbarui';
    //refresh page
    header("Location: suplier.php?page=tambah");
  }
}
