<?php
include '../config/koneksi.php';
$id_suplier = $_GET['id_suplier'];
// make deleete query

$query = "DELETE FROM suplier WHERE id_suplier = '$id_suplier'";

$result = mysqli_query($koneksi, $query);
if ($result) {
  // make a success message with session
  $_SESSION['result'] = 'success';
  $_SESSION['message'] = 'Data berhasil dihapus';

  header("Location: suplier.php");
} else {
  // make a success message with session
  $_SESSION['result'] = 'error';
  $_SESSION['message'] = 'Data gagal dihapus';
  //refresh page
  header("Location: suplier.php?page=tambah");
}
