 <title>Suplier</title>

 <?php
  include '../config/koneksi.php';
  // get id from url
  if (!isset($_GET['id_suplier'])) {
    header("Location: suplier.php");
  } else {
    $id_suplier = $_GET['id_suplier'];
    // get data from database
    $query = "SELECT * FROM suplier WHERE id_suplier = '$id_suplier'";
    $result = mysqli_query($koneksi, $query);
    $row = mysqli_fetch_assoc($result);
  }

  ?>

 <!-- Begin Page Content -->
 <div class="container-fluid">

   <!-- Page Heading -->
   <h1 class="h3 mb-4 text-gray-800">Suplier </h1>

   <div class="card card-body">
     <div class="row">
       <div class="col-12">
         <form action="suplier.php?page=proses" method="post" enctype="multipart/form-data">
           <input type="hidden" name="id_suplier" value="<?= $id_suplier ?>">
           <div class="row">

             <div class="col-6">
               <div class="form-group">
                 <label for="nama_suplier">Nama Suplier</label>
                 <input type="text" class="form-control" id="nama_suplier" name="nama_suplier" value="<?= $row['nama_suplier'] ?>">
               </div>
             </div>
             <div class="col-6">
               <div class="form-group">
                 <label for="nohp">Nomor Kontak</label>
                 <input type="text" class="form-control" id="nohp" name="nohp" value="<?= $row['nohp'] ?>">
               </div>
             </div>
             <div class="col-6">
               <div class="form-group">
                 <label for="note">Note</label>
                 <input type="text" class="form-control" id="note" name="note" value="<?= $row['note'] ?>">
               </div>
             </div>
           </div>


           <button name="update" value="update" class="btn btn-primary">Simpan</button>
         </form>
       </div>
     </div>
   </div>

 </div>
 <!-- /.container-fluid -->