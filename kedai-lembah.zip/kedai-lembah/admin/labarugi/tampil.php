<?php
include_once '../config/koneksi.php';
$no = 1;


// cari data
$bulan = '';
$tahun = '';
if (isset($_GET["bulan"]) && isset($_GET['tahun'])) {
    $bulan = $_GET["bulan"];
    $tahun = $_GET["tahun"];

    $tanggal_cocok = $tahun . '-' . $bulan;

    $data_penjualan = "SELECT SUM(total_belanja) AS total_penjualan FROM transaksi WHERE DATE_FORMAT(jam_transaksi, '%Y-%m') = '$tanggal_cocok'";
    $result_penjualan = mysqli_query($koneksi, $data_penjualan);

    if($result_penjualan->num_rows > 0){
        $total_penjualan_per_bulan = $result_penjualan->fetch_assoc();
        $nominal_total_pejualan = $total_penjualan_per_bulan['total_penjualan'];
    }else{
        $nominal_total_pejualan = 0;
    }

// barang masuk sama saja dengan pengeluaran kedai karea bertujuan untuk membeli barang
    $data_pengeluaran = "SELECT SUM(total_harga) AS total_pengeluaran FROM barang_masuk WHERE DATE_FORMAT(tgl_masuk, '%Y-%m') = '$tanggal_cocok'";
    $result_pengeluaran = mysqli_query($koneksi, $data_pengeluaran);

    if($result_pengeluaran->num_rows > 0){
        $total_pengeluaran_per_bulan = $result_pengeluaran->fetch_assoc();
        $nominal_total_pengeluaran = $total_pengeluaran_per_bulan['total_pengeluaran'];
    }else{
        $nominal_total_pengeluaran = 0;
    }


}


?>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Laporan Laba Rugi </h1>

    <div class="card card-body">
        <div class="row">
            <div class="col-12 d-flex justify-content-between">
                <div>
                    <a href="riwayattransaksi.php?page=export" class="btn btn-info" target="_blank">Print Data</a>
                </div>
                <form method="GET" class="d-flex">
                    <select name="bulan" id="bulan" class="rounded-sm mr-1 px-3" required>
                        <option value="" <?= $bulan == '' ? 'selected' : '' ?>>Pilih Bulan</option>
                        <option <?= $bulan == '01' ? 'selected' : '' ?> value="01">Januari</option>
                        <option <?= $bulan == '02' ? 'selected' : '' ?> value="02">Februari</option>
                        <option <?= $bulan == '03' ? 'selected' : '' ?> value="03">Maret</option>
                        <option <?= $bulan == '04' ? 'selected' : '' ?> value="04">April</option>
                        <option <?= $bulan == '05' ? 'selected' : '' ?> value="05">Mei</option>
                        <option <?= $bulan == '06' ? 'selected' : '' ?> value="06">Juni</option>
                        <option <?= $bulan == '07' ? 'selected' : '' ?> value="07">Juli</option>
                        <option <?= $bulan == '08' ? 'selected' : '' ?> value="08">Agustus</option>
                        <option <?= $bulan == '09' ? 'selected' : '' ?> value="09">September</option>
                        <option <?= $bulan == '10' ? 'selected' : '' ?> value="10">Oktober</option>
                        <option <?= $bulan == '11' ? 'selected' : '' ?> value="11">November</option>
                        <option <?= $bulan == '12' ? 'selected' : '' ?> value="12">Desember</option>
                    </select>
                    <select name="tahun" id="tahun" class="rounded-sm px-2 mr-1" required>
                        <?php
                        $thn = 2018;

                        ?>
                        <option value="" selected>Tahun</option>
                        <?php for ($thn = 2020; $thn <= 2030; $thn++) : ?>
                            <option value="<?= $thn ?>" <?= $tahun == $thn ? 'selected' : '' ?>><?= $thn ?></option>
                        <?php endfor; ?>
                    </select>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                </form>
            </div>
        </div>
    </div>

    <div class="card card-body mt-2">
        <div class="row">
            <div class="col-12">
                <?php
                if (isset($_SESSION['result'])) {
                    if ($_SESSION['result'] == 'success') {
                ?>
                        <!-- Success -->
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?= $_SESSION['message'] ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <!-- Success -->
                    <?php
                    } else {
                    ?>
                        <!-- danger -->
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?= $_SESSION['message'] ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <!-- danger -->
                <?php
                    }
                    unset($_SESSION['result']);
                    unset($_SESSION['message']);
                }
                ?>

            </div>
            <div class="col-12">
                <table class="table table-bordered" id="tableLaba" style="width: 100%;">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tahun</th>
                            <th>Bulan</th>
                            <th>Penjualan</th>
                            <th>Pengeluaran</th>
                            <th>Keuntungan</th>
                        </tr>
                    </thead>
                    <tbody>



                        <?php if ($bulan && $tahun && $result_penjualan->num_rows > 0 && $nominal_total_pejualan || $bulan && $tahun && $result_pengeluaran->num_rows > 0 && $nominal_total_pengeluaran) : ?>


                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $tahun; ?></td>
                                <td>
                                    <?php if ($bulan == '01') : ?>
                                        Januari
                                    <?php elseif ($bulan == '02') : ?>
                                        Februari
                                    <?php elseif ($bulan == '03') : ?>
                                        Maret
                                    <?php elseif ($bulan == '04') : ?>
                                        April
                                    <?php elseif ($bulan == '05') : ?>
                                        Mei
                                    <?php elseif ($bulan == '06') : ?>
                                        Juni
                                    <?php elseif ($bulan == '07') : ?>
                                        Juli
                                    <?php elseif ($bulan == '08') : ?>
                                        Agustus
                                    <?php elseif ($bulan == '09') : ?>
                                        September
                                    <?php elseif ($bulan == '10') : ?>
                                        Oktober
                                    <?php elseif ($bulan == '11') : ?>
                                        November
                                    <?php elseif ($bulan == '12') : ?>
                                        Desember
                                    <?php endif; ?>
                                </td>
                                <td><?= 'Rp ' . number_format($nominal_total_pejualan, 0, ',', '.') ?></td>
                                <td>
                                        <?= 'Rp ' . number_format($nominal_total_pengeluaran, 0, ',', '.') ?>
                                </td>
                                <td>
                                    <?php 
                                    $keuntungan = $nominal_total_pejualan - $nominal_total_pengeluaran;
                                    ?>
                                    <?php if($keuntungan < 0): ?>
                                    <span class="text-danger font-weight-bold">
                                        <?= 'Rp ' . number_format($keuntungan, 0, ',', '.') ?>
                                    </span>
                                    <?php else : ?>
                                        <span class="text-success font-weight-bold">
                                        <?= 'Rp ' . number_format($keuntungan, 0, ',', '.') ?>
                                    </span>
                                    <?php endif; ?>
                                </td>
                            </tr>

                        <?php endif; ?>




                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

