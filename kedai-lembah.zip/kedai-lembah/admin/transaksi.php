<?php
include '../modules/header.php';
include '../config/is_admin.php';
?>

<title>Transaksi</title>

<?php
// check page from url
if (isset($_GET['page'])) {
  $page = $_GET['page'];
} else {
  $page = 'tampil';
}
switch ($page) {
  case 'tampil':
    include 'transaksi/tampil.php';
    break;
  case 'tambah':
    include 'transaksi/tambah.php';
    break;
  case 'export':
    include 'transaksi/export.php';
    break;
  case 'exportdetail':
    include 'transaksi/exportdetail.php';
    break;
  case 'exportbulan':
    include 'transaksi/exportbulan.php';
    break;
  case 'exportperpelanggan':
    include 'transaksi/exportperpelanggan.php';
    break;
  case 'detail':
    include 'transaksi/detail.php';
    break;
  case 'proses':
    include 'transaksi/proses.php';
    break;
  case 'hapus':
    include 'transaksi/hapus.php';
    break;

  default:
    # code...
    break;
}
?>

<?php
include '../modules/footer.php';
?>