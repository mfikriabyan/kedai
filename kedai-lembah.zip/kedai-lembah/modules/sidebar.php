<ul class="navbar-nav sidebar sidebar-dark accordion" style="background-color: #014E00;" id="accordionSidebar">

  <!-- Sidebar - Brand -->
  <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
    <div class="sidebar-brand-icon ">
      <td>
        <img src="../assets/img/logo.png" height="60" alt="" class="gambar">
      </td>
    </div>
    <div class="sidebar-brand-text mx-3">Kedai Lembah </div>
  </a>

  <!-- Divider -->
  <hr class="sidebar-divider my-0">

  <!-- Nav Item - Dashboard -->


  <!-- Divider -->
  <hr class="sidebar-divider">
  <?php
  if ($_SESSION['role'] == 'admin') {
  ?>
    <div class="sidebar-heading">
      Master Data
    </div>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
        <i class="fas fa-database"></i>
        <span>Data</span>
      </a>
      <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
          <h6 class="collapse-header">Master Data:</h6>
          <a class="collapse-item" href="karyawan.php">Karyawan</a>
          <a class="collapse-item" href="barang.php">Barang</a>
          <a class="collapse-item" href="kategori.php">Kategori</a>
          <a class="collapse-item" href="suplier.php">Suplier</a>
          <a class="collapse-item" href="menu.php">Menu</a>
          <a class="collapse-item" href="pelanggan.php">Pelanggan</a>
        </div>
      </div>
    </li>

    <!-- Nav Item - Utilities Collapse Menu -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-cart-arrow-down"></i>
        <span>Transaksi</span>
      </a>
      <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">

          <a class="collapse-item" href="transaksi.php">Transaksi</a>
          <a class="collapse-item" href="riwayattransaksi.php">Laporan Penjualan</a>

          <a class="collapse-item" href="barangmasuk.php">Barang Masuk</a>
          <a class="collapse-item" href="barangkeluar.php">Barang Keluar</a>
        </div>
      </div>
    </li>
  <?php
  } elseif ($_SESSION['role'] == 'Kasir') {
  ?>
    <div class="sidebar-heading">
      Master Data
    </div>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
        <i class="fas fa-database"></i>
        <span>Data</span>
      </a>
      <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
          <h6 class="collapse-header">Master Data:</h6>
          <a class="collapse-item" href="menu.php">Menu</a>
          <a class="collapse-item" href="pelanggan.php">Pelanggan</a>
        </div>
      </div>
    </li>

    <!-- Nav Item - Utilities Collapse Menu -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-cart-arrow-down"></i>
        <span>Transaksi</span>
      </a>
      <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">

          <a class="collapse-item" href="transaksi.php">Transaksi</a>
          <a class="collapse-item" href="riwayattransaksi.php">Laporan Penjualan</a>
          <a class="collapse-item" href="barangmasuk.php">Barang Masuk</a>
          <a class="collapse-item" href="barangkeluar.php">Barang Keluar</a>

        </div>
      </div>
    </li>

  <?php
  }
  ?>
  <!-- Heading -->




  <!-- Divider -->
  <hr class="sidebar-divider d-none d-md-block">

  <!-- Sidebar Toggler (Sidebar) -->
  <div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
  </div>

</ul>